java vmsim -n 8 -a nru -r 1 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 2 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 3 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 4 gcc.trace >> NRU_gcc.txt

java vmsim -n 8 -a nru -r 5 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 11 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 12 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 13 gcc.trace >> NRU_gcc.txt

java vmsim -n 8 -a nru -r 14 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 15 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 16 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 17 gcc.trace >> NRU_gcc.txt

java vmsim -n 8 -a nru -r 18 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 19 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 20 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 21 gcc.trace >> NRU_gcc.txt

java vmsim -n 8 -a nru -r 30 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 50 gcc.trace >> NRU_gcc.txt
java vmsim -n 8 -a nru -r 100 gcc.trace >> NRU_gcc.txt