java vmsim -n 8 -a work -r 13 -t 5 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 13 -t 6 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 13 -t 7 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 13 -t 8 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 13 -t 9 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 13 -t 10 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 13 -t 11 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 13 -t 12 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 13 -t 13 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 13 -t 15 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 13 -t 16 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 13 -t 17 gcc.trace >> WORK_gcc.txt


java vmsim -n 8 -a work -r 21 -t 5 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 5 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 6 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 7 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 8 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 9 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 10 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 11 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 12 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 13 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 15 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 16 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 17 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 18 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 19 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 20 gcc.trace >> WORK_gcc.txt
java vmsim -n 8 -a work -r 21 -t 21 gcc.trace >> WORK_gcc.txt

